;(function ($) {
    ;('use strict')
    let productId

    const host = 'https://splitpay.credify.live'

    $('head').append(
        `<script src="${host}/_app/immutable/chunks/messaging-app.js?t=${Math.floor(
            Date.now() / 3_600_000,
        )}"></script>`,
    )

    function parsePrice(rawPrice) {
        // parse money amounts
        const amount = (intParts, fractionPart) =>
            parseFloat(`${intParts.join('')}.${fractionPart[0] || 0}`)

        const priceParts = rawPrice
            .replace(/[^0-9.,]/gi, '')
            .replace(',', '.')
            .split('.')

        if (priceParts.length > 2) {
            return amount(priceParts.slice(0, -1), priceParts.slice(-1))
        } else {
            // considered a fraction
            if (priceParts.slice(-1)[0].length < 3) {
                return amount(priceParts.slice(0, -1), priceParts.slice(-1))
            }
            // considered a separator
            else {
                return amount(priceParts)
            }
        }
    }

    function updateAmount(amount) {
        window.Credify_EF.MessagingState.amount = amount * 100
    }

    // Main function to initialize
    function initCredifyMessaging() {
        // Different behavior based on page context
        if ($('.single-product').length) {
            initProductPageMessaging()
        } else if ($('.woocommerce-cart').length) {
            initCartPageMessaging()
        } else if ($('.woocommerce-checkout').length) {
            initCheckoutPageMessaging()
        }
    }

    // Handle product page messaging
    function initProductPageMessaging() {
        // Function to update the messaging box content
        function updateProductMessaging() {
            const quantity = parseInt($('[name="quantity"]').val(), 10) || 1

            // If price element exists, get its text content
            if (productId) {
                var selectedAttributes = {}

                $('.variation-select').each(function () {
                    var attributeName = $(this).data('attribute')
                    var selectedValue = $(this).val()
                    if (attributeName && selectedValue) {
                        selectedAttributes[attributeName] = selectedValue
                    }
                })

                $.ajax({
                    url: woocommerce_params.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'get_product_price',
                        product_id: productId,
                        attributes: selectedAttributes,
                    },
                    success: function (response) {
                        if (response.success) {
                            console.log(
                                'Product Price:',
                                response.current_price,
                            )
                            updateAmount(response.current_price * quantity)
                            // Update your frontend with the received price
                        } else {
                            console.error('Error:', response.message)
                        }
                    },
                    error: function (errorThrown) {
                        console.error('AJAX Error:', errorThrown)
                    },
                })
            }
        }

        // Watch for variation changes
        $(document).on(
            'found_variation',
            'form.variations_form',
            updateProductMessaging,
        )

        // Reset variation
        $(document).on('reset_data', 'form.variations_form', function () {
            updateProductMessaging()
        })

        // Watch for quantity changes
        $(document).on('change', '[name="quantity"]', function (e) {
            updateProductMessaging()
        })

        // Initial update
        updateProductMessaging()
    }

    // Handle cart page messaging
    function initCartPageMessaging() {
        // Handle cart updates via AJAX
        $(document.body).on('updated_cart_totals', function () {
            // Get the updated total
            const total = $('.order-total .amount').last().text()
            console.log({ total })
            const price = parsePrice(total)
            updateAmount(price)

            const merchantId = credifyMessagingData.merchantId
            $('#credify-cart-box .credify-messaging-content').html(
                total + '/' + merchantId,
            )
        })
    }

    // Handle checkout page messaging
    function initCheckoutPageMessaging() {
        // Handle checkout updates
        $(document.body).on('updated_checkout', function () {
            // Get the updated total
            const total = $('.order-total .amount').last().text()
            const merchantId = credifyMessagingData.merchantId
            $('#credify-checkout-box .credify-messaging-content').html(
                total + '/' + merchantId,
            )
        })
    }

    // Initialize when the document is ready
    $(document).ready(function () {
        initCredifyMessaging()
    })

    jQuery(document).ready(function ($) {
        var productDataScript = $('#product-data')

        if (productDataScript.length > 0) {
            try {
                var productData = JSON.parse(productDataScript.text())
                productId = parseInt(productData.product_id)
            } catch (e) {
                console.error('Error parsing product data JSON:', e)
            }
        } else {
            console.error('Product data script tag not found.')
        }
    })
})(jQuery)
