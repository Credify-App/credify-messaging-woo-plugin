<?php
/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 */
class Credify_Messaging
{

    /**
     * The admin object that's responsible for admin area functionality.
     *
     * @var object
     */
    protected $admin;

    /**
     * The public object that's responsible for public-facing functionality.
     *
     * @var object
     */
    protected $public;

    /**
     * Define the core functionality of the plugin.
     */
    public function __construct()
    {
        $this->load_dependencies();
    }

    /**
     * Load the required dependencies for this plugin.
     */
    private function load_dependencies()
    {
        // Admin area
        require_once CREDIFY_MESSAGING_PLUGIN_PATH . 'admin/class-credify-messaging-admin.php';
        $this->admin = new Credify_Admin();

        // Public area
        require_once CREDIFY_MESSAGING_PLUGIN_PATH . 'public/class-credify-messaging-public.php';
        $this->public = new Credify_Public();
    }

    /**
     * Run the plugin.
     */
    public function run()
    {
        $this->admin->init();
        $this->public->init();
    }

    /**
     * Activate the plugin.
     */
    public static function activate()
    {
        // Set default merchant ID if not already set
        if (!get_option('credify_store_id')) {
            update_option('credify_store_id', 'DEFAULT_MERCHANT');
        }
    }

    /**
     * Deactivate the plugin.
     */
    public static function deactivate()
    {
        // Plugin deactivation logic here
    }
}