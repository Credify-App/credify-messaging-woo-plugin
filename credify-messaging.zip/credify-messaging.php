<?php
/**
 * Plugin Name: Credify Messaging
 * Plugin URI: https://example.com/credify-messaging
 * Description: Displays pricing information in WooCommerce product, cart, and checkout pages.
 * Version: 1.0.0
 * Author: Credify
 * Text Domain: credify-messaging
 * Domain Path: /languages
 * WC requires at least: 3.0.0
 * WC tested up to: 8.0.0
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Define plugin constants
define('CREDIFY_MESSAGING_VERSION', '1.0.0');
define('CREDIFY_MESSAGING_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('CREDIFY_MESSAGING_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include the main plugin class
require_once CREDIFY_MESSAGING_PLUGIN_PATH . 'includes/class-credify-messaging.php';

// Activation and deactivation hooks
register_activation_hook(__FILE__, array('Credify_Messaging', 'activate'));
register_deactivation_hook(__FILE__, array('Credify_Messaging', 'deactivate'));


/**
 * Extended function to get the product price (including variants) in JSON format.
 *
 * @param int $product_id The ID of the product.
 * @param array $attributes An array of selected variation attributes (optional).
 * @return void Sends a JSON response with the product price.
 */
function my_plugin_get_product_price_json_extended($product_id, $attributes = array())
{
    $product = wc_get_product($product_id);

    if (!$product) {
        wp_send_json_error(array('message' => 'Product not found.'));
        return;
    }

    if ($product->is_type('variable') && !empty($attributes)) {
        // Get the matching variation ID based on the provided attributes
        $variation_id = $product->get_matching_variation($attributes);

        if ($variation_id) {
            $variation = wc_get_product($variation_id);
            if ($variation) {
                $sale_price = $variation->get_sale_price();
                $regular_price = $variation->get_regular_price();
                $current_price = '';

                if (!empty($sale_price)) {
                    $current_price = $sale_price;
                } else {
                    $current_price = $variation->get_price();
                }

                $response_data = array(
                    'success' => true,
                    'product_id' => $product_id,
                    'variation_id' => $variation_id,
                    'current_price' => $current_price,
                    'regular_price' => $regular_price,
                    'sale_price' => $sale_price,
                    'on_sale' => $variation->is_on_sale(),
                );

                wp_send_json($response_data);
                return;
            } else {
                wp_send_json_error(array('message' => 'Variation not found.'));
                return;
            }
        } else {
            wp_send_json_error(array('message' => 'No matching variation found for the given attributes.'));
            return;
        }
    } else {
        // Handle simple products or variable products without selected attributes
        $sale_price = $product->get_sale_price();
        $regular_price = $product->get_regular_price();
        $current_price = '';

        if (!empty($sale_price)) {
            $current_price = $sale_price;
        } else {
            $current_price = $product->get_price();
        }

        $response_data = array(
            'success' => true,
            'product_id' => $product_id,
            'current_price' => $current_price,
            'regular_price' => $regular_price,
            'sale_price' => $sale_price,
            'on_sale' => $product->is_on_sale(),
        );
        wp_send_json($response_data);
    }
}

/**
 * Begins execution of the plugin.
 */
function run_credify_messaging()
{
    $plugin = new Credify_Messaging();

    function my_plugin_handle_ajax_get_product_price_extended()
    {
        if (isset($_POST['product_id']) && is_numeric($_POST['product_id'])) {
            $product_id = intval($_POST['product_id']);
            // Expecting attributes to be sent as a JSON string or an array
            $attributes_data = isset($_POST['attributes']) ? wp_unslash($_POST['attributes']) : '';
            $attributes = array();

            // Try to decode JSON string if it was sent that way
            $decoded_attributes = json_decode($attributes_data, true);
            if (is_array($decoded_attributes)) {
                $attributes = $decoded_attributes;
            } elseif (is_array($_POST['attributes'])) {
                // Handle if attributes were sent as a standard form array
                $attributes = $_POST['attributes'];
            }

            my_plugin_get_product_price_json_extended($product_id, $attributes);
        } else {
            wp_send_json_error(array('message' => 'Invalid product ID.'));
        }
    }


    /**
     * Function to output product ID as JSON in a script tag.
     */
    function my_plugin_output_product_id_script()
    {
        if (is_product()) {
            global $product;
            if ($product) {
                $product_data = array(
                    'product_id' => $product->get_id(),
                );
                $product_data_json = wp_json_encode($product_data);
                echo '<script type="application/json" id="product-data">' . $product_data_json . '</script>';
            }
        }
    }

    // Example AJAX handler (modified to accept attributes)
    add_action('wp_ajax_get_product_price', 'my_plugin_handle_ajax_get_product_price_extended');
    add_action('wp_ajax_nopriv_get_product_price', 'my_plugin_handle_ajax_get_product_price_extended');
    add_action('wp_footer', 'my_plugin_output_product_id_script');


    $plugin->run();
}

// Check if WooCommerce is active
if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    run_credify_messaging();
} else {
    add_action('admin_notices', function () {
        ?>
        <div class="notice notice-error">
            <p><?php _e('Credify Messaging requires WooCommerce to be installed and active.', 'credify-messaging'); ?></p>
        </div>
        <?php
    });
}