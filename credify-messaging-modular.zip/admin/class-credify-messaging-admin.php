<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and hooks for enqueueing
 * the admin-specific stylesheet and JavaScript.
 *
 * @package    Credify_Messaging
 * @subpackage Credify_Messaging/admin
 * @author     Your Name <your.email@example.com>
 */
class Credify_Admin
{

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     */
    public function __construct()
    {
        // Constructor logic (if any)
    }

    /**
     * Register all of the hooks related to the admin area functionality
     * of the plugin.
     *
     * @since    1.0.0
     */
    public function init()
    {
        // Hook to add the admin menu page
        add_action('admin_menu', array($this, 'add_plugin_admin_menu'));
        // Hook to register plugin settings
        add_action('admin_init', array($this, 'register_settings'));
    }

    /**
     * Add options page to the admin menu.
     *
     * Adds a submenu page under the WooCommerce menu.
     *
     * @since    1.0.0
     */
    public function add_plugin_admin_menu()
    {
        add_submenu_page(
            'woocommerce', // Parent slug (WooCommerce menu)
            __('Credify Messaging Settings', 'credify-messaging'), // Page title
            __('Credify Messaging', 'credify-messaging'),          // Menu title
            'manage_options', // Capability required
            'credify-messaging', // Menu slug
            array($this, 'display_plugin_admin_page') // Function to display the page
        );
    }

    /**
     * Register plugin settings using the Settings API.
     *
     * Registers the setting group and individual settings fields.
     *
     * @since    1.0.0
     */
    public function register_settings()
    {
        // Register the main settings group
        // All options will belong to this group and use the same options.php handler
        $option_group = 'credify_settings_group';

        // Register Store ID Setting
        register_setting(
            $option_group,            // Option group
            'credify_store_id',       // Option name (stored in wp_options)
            array(                    // Arguments
                'type' => 'string',
                'sanitize_callback' => 'sanitize_text_field', // Sanitize input as plain text
                'default' => 'DEFAULT_MERCHANT',    // Default value if not set
                'show_in_rest' => false,                 // Not needed for REST API currently
            )
        );

        // Register Product Page Hook Setting - NEW
        register_setting(
            $option_group,               // Option group
            'credify_product_page_hook', // Option name
            array(                       // Arguments
                'type' => 'string',
                'sanitize_callback' => 'sanitize_text_field', // Sanitize hook name
                'default' => 'woocommerce_before_add_to_cart_form', // Default hook
                'show_in_rest' => false,
            )
        );

        // Register Cart Page Hook Setting - NEW
        register_setting(
            $option_group,            // Option group
            'credify_cart_page_hook', // Option name
            array(                    // Arguments
                'type' => 'string',
                'sanitize_callback' => 'sanitize_text_field', // Sanitize hook name
                'default' => 'woocommerce_cart_totals_after_order_total', // Default hook
                'show_in_rest' => false,
            )
        );

        // Note: If you had more complex settings or wanted sections,
        // you would use add_settings_section() and add_settings_field() here.
        // For this simple case, directly outputting the fields in the display function is sufficient.
    }

    /**
     * Render the settings page for the plugin.
     *
     * Outputs the HTML for the settings form.
     *
     * @since    1.0.0
     */
    public function display_plugin_admin_page()
    {
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            return;
        }
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <?php settings_errors(); ?>

            <form method="post" action="options.php">
                <?php
                // Output necessary hidden fields for the Settings API (nonce, action, option_page)
                settings_fields('credify_settings_group');
                ?>
                <table class="form-table" role="presentation">
                    <tbody>
                        <tr>
                            <th scope="row">
                                <label for="credify_store_id"><?php esc_html_e('Store ID', 'credify-messaging'); ?></label>
                                </th>
                                <td>
                                    <input type="text" id="credify_store_id" name="credify_store_id"
                                        value="<?php echo esc_attr(get_option('credify_store_id', 'DEFAULT_MERCHANT')); ?>" class="regular-text">
                                    <p class="description">
                                    <?php esc_html_e('Enter your merchant ID provided by Credify.', 'credify-messaging'); ?>
                                    </p>
                                    </td>
                                    </tr>
                                    
                                    <tr>
                                        <th scope="row">
                                            <label for="credify_product_page_hook"><?php esc_html_e('Product Page Hook', 'credify-messaging'); ?></label>
                                        </th>
                                        <td>
                                            <input type="text" id="credify_product_page_hook" name="credify_product_page_hook"
                                                value="<?php echo esc_attr(get_option('credify_product_page_hook', 'woocommerce_before_add_to_cart_form')); ?>"
                                                class="regular-text">
                                            <p class="description">
                                                <?php esc_html_e('Enter the WooCommerce action hook name used to display messaging on the product page (e.g., near variations or add-to-cart).', 'credify-messaging'); ?>
                                                <br>
                                                <i><?php printf(esc_html__('Default: %s', 'credify-messaging'), '<code>woocommerce_before_add_to_cart_form</code>'); ?></i>
                                            </p>
                                        </td>
                                    </tr>
                                    
                                    <tr>
                                        <th scope="row">
                                            <label for="credify_cart_page_hook"><?php esc_html_e('Cart Page Hook', 'credify-messaging'); ?></label>
                                        </th>
                                        <td>
                                            <input type="text" id="credify_cart_page_hook" name="credify_cart_page_hook"
                                                value="<?php echo esc_attr(get_option('credify_cart_page_hook', 'woocommerce_cart_totals_after_order_total')); ?>"
                                                class="regular-text">
                                            <p class="description">
                                                <?php esc_html_e('Enter the WooCommerce action hook name used to display messaging on the cart page (e.g., after cart totals).', 'credify-messaging'); ?>
                                                <br>
                                                <i><?php printf(esc_html__('Default: %s', 'credify-messaging'), '<code>woocommerce_cart_totals_after_order_total</code>'); ?></i>
                                                </p>
                                                </td>
                                                </tr>
                    </tbody>
                </table>
                <?php
                    // Output the submit button
                    submit_button(__('Save Settings', 'credify-messaging'));
                    ?>
            </form>
        </div>
        <?php
    }
}

?>