<?php
/**
 * The public-facing functionality of the plugin.
 */
class Credify_Public
{

    /**
     * Initialize the class and set its properties.
     */
    public function __construct()
    {
        // Constructor logic
    }

    /**
     * Register all of the hooks related to the public-facing functionality.
     */
    public function init()
    {
        // Enqueue scripts and styles
        add_action('wp_enqueue_scripts', array($this, 'enqueue_styles'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));

        $credify_product_page_hook = get_option('credify_product_page_hook', 'woocommerce_before_add_to_cart_form');
        $credify_cart_page_hook = get_option('credify_cart_page_hook', 'woocommerce_cart_totals_after_order_total');

        // WooCommerce hooks for product page
        add_action($credify_product_page_hook, array($this, 'display_product_messaging'), 25);

        // WooCommerce hooks for cart page
        add_action($credify_cart_page_hook, array($this, 'display_cart_messaging'));

        // WooCommerce hooks for checkout page
        // add_action('woocommerce_review_order_after_order_total', array($this, 'display_checkout_messaging'));
    }

    /**
     * Register the stylesheets for the public-facing side of the site.
     */
    public function enqueue_styles()
    {
        // Only enqueue on relevant WooCommerce pages
        if (is_product() || is_cart() || is_checkout()) {
            wp_enqueue_style(
                'credify-messaging-css',
                CREDIFY_MESSAGING_PLUGIN_URL . 'assets/css/credify-messaging.css',
                array(),
                CREDIFY_MESSAGING_VERSION,
                'all'
            );
        }
    }

    /**
     * Register the JavaScript for the public-facing side of the site.
     */
    public function enqueue_scripts()
    {
        // Only enqueue on relevant WooCommerce pages
        if (is_product() || is_cart() || is_checkout()) {
            wp_enqueue_script(
                'credify-messaging-js',
                CREDIFY_MESSAGING_PLUGIN_URL . 'assets/js/credify-messaging.js',
                array('jquery'),
                CREDIFY_MESSAGING_VERSION,
                true
            );

            // Pass data to JavaScript
            wp_localize_script(
                'credify-messaging-js',
                'credifyMessagingData',
                array(
                    'storeId' => get_option('credify_store_id', 'DEFAULT_MERCHANT'),
                    'ajaxUrl' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce('credify-messaging-nonce'),
                )
            );
        }
    }

    /**
     * Display messaging box on product page.
     */
    public function display_product_messaging()
    {
        global $product;

        if (!$product) {
            return;
        }

        $store_id = get_option('credify_store_id', 'DEFAULT_MERCHANT');
        $price = $product->get_price();

        $ef_obj = [
            "platform" => 'woocommerce',
            "storeId" => $store_id,
            'MessagingState' => [
                'page' => 'product',
                'amount' => $price * 100
            ],
        ];

        echo '<script>window.Credify_EF = ' . json_encode($ef_obj) . '</script>';
        echo '<div id="credify-app"></div>';
    }

    /**
     * Display messaging box on cart page.
     */
    public function display_cart_messaging()
    {
        $store_id = get_option('credify_store_id', 'DEFAULT_MERCHANT');
        $cart_total = WC()->cart->get_total(false);

        $ef_obj = [
            "platform" => 'woocommerce',
            "storeId" => $store_id,
            'MessagingState' => [
                'page' => 'cart',
                'amount' => $cart_total * 100
            ],
        ];
        echo '<script>window.Credify_EF = ' . json_encode($ef_obj) . '</script>';
        echo '<div id="credify-app"></div>';
    }

    /**
     * Display messaging box on checkout page.
     */
    public function display_checkout_messaging()
    {
        $store_id = get_option('credify_store_id', 'DEFAULT_MERCHANT');
        $order_total = WC()->cart->get_total(false);

        echo '<tr class="credify-messaging-container">';
        echo '<th>' . __('Credify Messaging', 'credify-messaging') . '</th>';
        echo '<td>';
        echo '<div class="credify-messaging-box" id="credify-checkout-box" data-context="checkout">';
        echo '<div class="credify-messaging-content">' . wc_price($order_total) . '/' . $store_id . '</div>';
        echo '</div>';
        echo '</td>';
        echo '</tr>';
    }
}